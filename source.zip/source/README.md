# Manga Reader 源码

这个文件夹就是 Manga Reader 的全部源码 —— 只有两个 C# 文件，零第三方依赖。

| 文件 | 内容 |
| --- | --- |
| `Mobi.cs` | PalmDB / MOBI / AZW3(KF8) 解析、EXTH 读取、内嵌图片提取与裁剪、图片尺寸解析、解压缓存 |
| `Reader.cs` | WPF 界面：翻页、阅读方向、连续卷动、缩放、全屏、工具栏显隐、设置持久化、程序入口 |

编译目标是 **.NET Framework 4.x**，代码使用 C# 5 语法，只用 Windows 自带的 `csc.exe`，不需要 Visual Studio。

---

## 方式一：用项目根目录的脚本

在项目根目录双击 `build.cmd`（只编译），或者双击 `MangaReader.bat`
（先判断源码是不是比 exe 新，需要才重新编译，然后启动）。

---

## 方式二：手工编译

把这个 `source` 文件夹单独拷走也能编译：

```bat
set CSC=%WINDIR%\Microsoft.NET\Framework64\v4.0.30319\csc.exe
set WPF=%WINDIR%\Microsoft.NET\Framework64\v4.0.30319\WPF
set FW=%WINDIR%\Microsoft.NET\Framework64\v4.0.30319

"%CSC%" /nologo /target:winexe /optimize+ /out:"Manga Reader.exe" ^
  /reference:"%WPF%\PresentationFramework.dll" ^
  /reference:"%WPF%\PresentationCore.dll" ^
  /reference:"%WPF%\WindowsBase.dll" ^
  /reference:"%FW%\System.Xaml.dll" ^
  Mobi.cs Reader.cs
```

32 位系统上把 `Framework64` 换成 `Framework`。

---

## 内置的两个无界面模式

程序自带两个不需要开窗口的模式，方便批量验证和截图（出错会写 `.err.txt`，不会弹对话框）：

```
Manga Reader.exe --selftest  <书.mobi> <报告.txt>
Manga Reader.exe --render-ui <书.mobi> <输出.png> [宽] [高] [cont|single|double] [rtl|ltr] [页] [额外滚动] [缩放档位]
```

`--render-ui` 的缩放档位：`0`=适应页面 `1`=适应宽度 `2`=50% `3`=75% `4`=100% `5`=125% `6`=150% `7`=200% `8`=300%。

---

## 代码结构速览

`Mobi.cs`

- `MobiFile` —— 打开一个 `.mobi` / `.azw3`，解析记录表、MOBI 头、EXTH，给出图片记录列表
- `ImageGeometry` —— 图片尾部填充裁剪 + 从文件头读宽高
- `BookLoader` —— 把若干文件拼成一本书，并把内嵌图片解压到缓存目录
- `PageEntry` / `ChapterInfo` / `Book` —— 数据模型

`Reader.cs`

- `ImageCache` / `PageToImageConverter` / `ZoomWidthConverter` —— 解码缓存与绑定转换器
- `Settings` —— `%LOCALAPPDATA%\MangaReader\settings.ini` 读写
- `UI` —— 按钮 / 下拉框的小工厂
- `MainWindow` —— 界面、翻页、连续卷动、缩放、全屏、工具栏显隐
- `Program` —— 入口，以及 `--selftest` / `--render-ui`
